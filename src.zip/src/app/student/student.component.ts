import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Student } from '../../model/Student';

@Component({
  selector: 'app-student',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './student.component.html',
  styleUrl: './student.component.css'
})
export class StudentComponent {
  students:Student[] = []
  showmsg:string=' '
  colorClass:string=' '
  constructor()
  {
    let s1=new Student(1, "Amit", 2, 80, ["JAVA", "Python"])
    let s2=new Student(2, "Sumit", 3, 88, ["English", "Python"])
    let s3=new Student(3, "Rohit", 5, 89, ["JAVA", "English"])
    let s4=new Student(4, "Ronit", 4, 85, ["JAVA", "Maths"])
    let s5=new Student(5, "Ankit", 6, 84, ["Maths", "Python"])
    this.students.push(s1)
    this.students.push(s2)
    this.students.push(s3)
    this.students.push(s4)
    this.students.push(s5)


  }
  showStudents()
  {
    
  }
  deleteStudent(rollno:number)
  {
    const result = confirm('Are you sure?')
    if(result)
    {
      this.showmsg='Record Deleted'
      this.colorClass='success'
      this.students=this.students.filter(s => s.rollno != rollno)
    }
    else
    {
      this.showmsg='Deletion cancelled'
      this.colorClass='error'
    }
  }
  updateStudent(s:Student)
  {
    console.log(s);
  }
}
