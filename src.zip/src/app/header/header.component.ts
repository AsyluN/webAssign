import { Component } from "@angular/core";

@Component({
    templateUrl:'./header.component.html', 
    styleUrls:['./header.component.css'], 
    selector:'app-header',
    standalone:true
})
class HeaderComponent
{
    message = "Student Management App"

    sayHello():string
    {
        return "Method works";
    }
}
export default HeaderComponent